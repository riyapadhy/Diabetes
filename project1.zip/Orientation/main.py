import gradio as gr
import pandas as pd
import joblib

# Load the trained model
model = joblib.load("depression_model.joblib")

# Label mapping
label_map = {0: "Not Depressed", 1: "Depressed"}

# Define the prediction function
def predict_depression(screen_time, num_calls, num_sms, mobility_entropy):
    # Create a DataFrame from the inputs
    input_df = pd.DataFrame([{
        "screen_time": float(screen_time),
        "num_calls": int(num_calls),
        "num_sms": int(num_sms),
        "mobility_entropy": float(mobility_entropy)
    }])
    
    # Make prediction
    prediction = model.predict(input_df)[0]
    return label_map[prediction]

# Gradio interface
iface = gr.Interface(
    fn=predict_depression,
    inputs=[
        gr.Number(label="Screen Time (in hours)"),
        gr.Number(label="Number of Calls"),
        gr.Number(label="Number of SMS"),
        gr.Number(label="Mobility Entropy")
    ],
    outputs=gr.Text(label="Prediction"),
    title="Depression Predictor",
    description="Enter digital behavior metrics to predict depression status (based on trained ML model)"
)

# Launch the app
if __name__ == "__main__":
    iface.launch()
